# Update 
The website is now available it's up and running but please note that on Wednesday there will be a new branch added because I have have a completely new layout. If you have forked this repo make sure to sync it to update and then deploy your own version of the aniwatch API. I have set cors on the api this website is using . 

# Project Title
AniTeams
## Description

An anime streaming website that uses  [Aniwatch Api ](https://github.com/ghoshRitesh12/aniwatch-api). Made with HTML , CSS and JS only.

## Features

- Feature 1: Uses the Artplayer.js 
- Feature 2: the player include chromecast,  screenshot for desktop devices , and audio (sub or dub)


## Contact
this is my first project that I am making public , if you have an problems suggestion or feedback , please list them in issues . I hope you enjoy using this website 
Thank you .
